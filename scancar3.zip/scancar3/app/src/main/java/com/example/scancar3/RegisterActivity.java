package com.example.scancar3;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class RegisterActivity extends AppCompatActivity {

    private EditText newUsername, newPassword;
    private Button registerButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        newUsername = findViewById(R.id.new_username);
        newPassword = findViewById(R.id.new_password);
        registerButton = findViewById(R.id.register_button);

        registerButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String user = newUsername.getText().toString();
                String pass = newPassword.getText().toString();

                if (!user.isEmpty() && !pass.isEmpty()) {
                    // Devolver los datos del nuevo usuario a MainActivity
                    Intent resultIntent = new Intent();
                    resultIntent.putExtra("newUser", user);
                    resultIntent.putExtra("newPass", pass);
                    setResult(RESULT_OK, resultIntent);
                    finish();
                } else {
                    Toast.makeText(RegisterActivity.this, "Por favor, ingrese todos los campos", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}
