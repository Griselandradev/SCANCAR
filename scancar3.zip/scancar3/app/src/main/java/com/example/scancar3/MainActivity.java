package com.example.scancar3;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.util.HashMap;
import java.util.Objects;

public class MainActivity extends AppCompatActivity {

    private EditText username, password;

    // Utilizamos un HashMap para simular una base de datos de usuarios registrados
    private HashMap<String, String> userDatabase;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        username = findViewById(R.id.username);
        password = findViewById(R.id.password);
        Button loginButton = findViewById(R.id.login_button);
        Button registerButton = findViewById(R.id.register_button);

        // Inicializamos el "database" de usuarios con un usuario predeterminado
        userDatabase = new HashMap<>();
        userDatabase.put("Gri", "1234"); // Usuario predeterminado para pruebas

        loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                handleLogin();
            }
        });

        registerButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Navegar a la actividad de registro
                Intent intent = new Intent(MainActivity.this, RegisterActivity.class);
                startActivityForResult(intent, 1); // Usamos startActivityForResult para recibir resultados
            }
        });
    }

    private void handleLogin() {
        String user = username.getText().toString();
        String pass = password.getText().toString();

        if (userDatabase.containsKey(user) && Objects.equals(userDatabase.get(user), pass)) {
            // Inicia la nueva actividad (el menú)
            Intent intent = new Intent(MainActivity.this, Menu.class);
            startActivity(intent);
        } else {
            Toast.makeText(MainActivity.this, "Usuario o contraseña incorrectos", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 1 && resultCode == RESULT_OK) {
            // Obtener el nombre de usuario y la contraseña del registro
            String newUser = data.getStringExtra("newUser");
            String newPass = data.getStringExtra("newPass");

            if (newUser != null && newPass != null) {
                // Agregar el nuevo usuario a la "base de datos"
                userDatabase.put(newUser, newPass);
                Toast.makeText(MainActivity.this, "Registro exitoso", Toast.LENGTH_SHORT).show();
            }
        }
    }
}
